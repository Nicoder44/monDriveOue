# Exercice 1

## Quel est le contenu du message ? Donnez la liste des instructions, commandes, etc utilisées.

Pour cette premiere question, nous avons une empreinte MD5 (b40c600c9e8b436ffb554756920c4b77) et nous savons que le chiffrement utilisé est AES-128 CBC.